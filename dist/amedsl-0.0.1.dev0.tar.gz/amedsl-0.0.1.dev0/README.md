# Asset Management Engine DSL

A domain-specific language for asset management modelling tasks

## Build

```cmd
python -m build
```